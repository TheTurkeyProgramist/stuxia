# Stykhiia Text

A glyphic sans serif with flared stroke endings for the weather website **Стихія (Stykhiia)**.
Шрифт з розширеними кінцями штрихів для погодного сайту «Стихія».

- Coverage: GF Latin Core, GF Cyrillic Core, Latin Extended-A (499 glyphs)
- Features: kern, mark/mkmk, ccmp (soft-dotted i/j), tnum (tabular figures)
- Weather icons (PUA): U+E000 sun · E001 cloud · E002 rain · E003 snow · E004 wind
- License: SIL Open Font License 1.1 (see OFL.txt)

## Building

    pip install -r requirements.txt
    cd sources/generator
    python build_ufo.py ../../build       # writes the UFO, builds TTF with fontmake, autohints, makes WOFF2

`sources/StykhiiaText.ufo` is the editable source (cubic Bézier outlines, components and anchors).
The Python generator in `sources/generator` is how the UFO was produced.

## Quality

- FontBakery (googlefonts profile): 0 FAIL, 0 ERROR — see `documentation/fontbakery-report.md`
- Uniqueness vs 87 popular fonts (skeleton comparison): see `documentation/uniqueness-report.txt`

Before submitting to Google Fonts: replace `YOUR-GITHUB` in OFL.txt and in `build_ufo.py` with the real repository URL.
